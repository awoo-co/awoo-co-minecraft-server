this app (tailscale) is required because it needs it to connect to the minecraft server

share link
https://login.tailscale.com/admin/invite/T78DjGrZ9s67K8XcNhKB21
